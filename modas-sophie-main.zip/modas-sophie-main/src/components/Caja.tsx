import { useCallback, useEffect, useMemo, useState } from 'react'
import { supabase } from '../lib/supabase'
import PageHeader from "./PageHeader"

type CajaProps = {
  userId: string
  userRole: string
  onBack: () => void
}

type Branch = {
  id: string
  name: string
}

type CashRegister = {
  id: string
  branch_id: string
  opened_by: string
  opened_at: string
  opening_cash: number
  status: 'open' | 'closed'
  closed_by: string | null
  closed_at: string | null
  counted_cash: number | null
  expected_cash: number | null
  difference: number | null
  notes: string | null
}

type Sale = {
  total: number
  payment_method: string
}

type Expense = {
  amount: number
}

function money(value: number) {
  return `$${value.toFixed(2)}`
}

export default function Caja({ userId, userRole, onBack }: CajaProps) {
  const [branches, setBranches] = useState<Branch[]>([])
  const [branchId, setBranchId] = useState('')
  const [cashRegister, setCashRegister] = useState<CashRegister | null>(null)

  const [openingCash, setOpeningCash] = useState(() => {
    return localStorage.getItem('modas-sophie-opening-cash') ?? ''
  })
  const [cashCounted, setCashCounted] = useState(() => {
    return localStorage.getItem('modas-sophie-cash-counted') ?? ''
  })

  const [sales, setSales] = useState<Sale[]>([])
  const [expenses, setExpenses] = useState<Expense[]>([])

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const loadCaja = useCallback(async () => {
    setLoading(true)
    setError('')
    setMessage('')

    const { data: branchData, error: branchError } = await supabase
      .from('branches')
      .select('id,name')
      .eq('active', true)
      .order('name')

    if (branchError) {
      setError(branchError.message)
      setLoading(false)
      return
    }

    const safeBranches = (branchData ?? []) as Branch[]
    setBranches(safeBranches)

    const currentBranchId = branchId || safeBranches[0]?.id || ''

    if (!currentBranchId) {
      setLoading(false)
      return
    }

    if (!branchId) {
      setBranchId(currentBranchId)
    }

    const { data: registerData, error: registerError } = await supabase
      .from('cash_registers')
      .select(
        'id,branch_id,opened_by,opened_at,opening_cash,status,closed_by,closed_at,counted_cash,expected_cash,difference,notes'
      )
      .eq('branch_id', currentBranchId)
      .eq('status', 'open')
      .maybeSingle()

    if (registerError) {
      setError(registerError.message)
      setLoading(false)
      return
    }

    const currentRegister = (registerData ?? null) as CashRegister | null
    setCashRegister(currentRegister)

    if (currentRegister) {
      const [salesResult, expensesResult] = await Promise.all([
        supabase
          .from('sales')
          .select('total,payment_method')
          .eq('cash_register_id', currentRegister.id),

        supabase
          .from('expenses')
          .select('amount')
          .eq('cash_register_id', currentRegister.id),
      ])

      if (salesResult.error) {
        setError(salesResult.error.message)
      } else {
        setSales((salesResult.data ?? []) as Sale[])
      }

      if (expensesResult.error) {
        setError(expensesResult.error.message)
      } else {
        setExpenses((expensesResult.data ?? []) as Expense[])
      }
    } else {
      setSales([])
      setExpenses([])
    }

    setLoading(false)
  }, [branchId])

  useEffect(() => {
    loadCaja()

    const handleDataUpdated = () => {
      loadCaja()
    }

    window.addEventListener('modas-sophie-data-updated', handleDataUpdated)

    return () => {
      window.removeEventListener('modas-sophie-data-updated', handleDataUpdated)
    }
  }, [loadCaja])

  const efectivoVentas = useMemo(
    () =>
      sales
        .filter((sale) => sale.payment_method === 'efectivo')
        .reduce((sum, sale) => sum + Number(sale.total), 0),
    [sales]
  )

  const totalGastos = useMemo(
    () => expenses.reduce((sum, expense) => sum + Number(expense.amount), 0),
    [expenses]
  )

  useEffect(() => {
    localStorage.setItem('modas-sophie-opening-cash', openingCash)
  }, [openingCash])

  useEffect(() => {
    localStorage.setItem('modas-sophie-cash-counted', cashCounted)
  }, [cashCounted])

  const efectivoEsperado = useMemo(
    () =>
      Number(cashRegister?.opening_cash ?? 0) +
      efectivoVentas -
      totalGastos,
    [cashRegister, efectivoVentas, totalGastos]
  )

  const diferencia =
    cashCounted.trim() === ''
      ? null
      : Number(cashCounted) - efectivoEsperado

  async function abrirCaja() {
    setError('')
    setMessage('')

    if (!branchId) {
      setError('Selecciona una sucursal.')
      return
    }

    
  if (openingCash.trim() === '') {
    setError('Ingresa el efectivo inicial para abrir la caja.')
    return
  }

  const amount = Number(openingCash)

  if (!Number.isFinite(amount) || amount < 0) {
    setError('Ingresa un efectivo inicial válido.')
    return
  }

setSaving(true)

    const { error: insertError } = await supabase
      .from('cash_registers')
      .insert({
        branch_id: branchId,
        opened_by: userId,
        opening_cash: amount,
        status: 'open',
      })

    if (insertError) {
      setError(
        insertError.code === '23505'
          ? 'Esta sucursal ya tiene una caja abierta.'
          : insertError.message
      )
      setSaving(false)
      return
    }

    setOpeningCash('')
    localStorage.removeItem('modas-sophie-opening-cash')
    setMessage('Caja abierta correctamente.')
    setSaving(false)

    window.dispatchEvent(new Event('modas-sophie-data-updated'))
    await loadCaja()
  }

  async function cerrarCaja() {
    setError('')
    setMessage('')

    if (!cashRegister) {
      setError('No hay una caja abierta.')
      return
    }

    if (cashCounted.trim() === '') {
      setError('Ingresa el efectivo contado físicamente.')
      return
    }

    const counted = Number(cashCounted)

    if (!Number.isFinite(counted) || counted < 0) {
      setError('Ingresa un efectivo contado válido.')
      return
    }

    setSaving(true)

    const { data: closedRegister, error: updateError } = await supabase
      .from('cash_registers')
      .update({
        status: 'closed',
        closed_by: userId,
        closed_at: new Date().toISOString(),
        counted_cash: counted,
        expected_cash: efectivoEsperado,
        difference: counted - efectivoEsperado,
      })
      .eq('id', cashRegister.id)
      .eq('status', 'open')
      .select('id,status,closed_at')
      .maybeSingle()

    if (updateError) {
      setError(`No se pudo cerrar la caja: ${updateError.message}`)
      setSaving(false)
      return
    }

    if (!closedRegister || closedRegister.status !== 'closed') {
      setError(
        'La caja no pudo cerrarse realmente en la base de datos. Verifica los permisos de la caja e inténtalo nuevamente.'
      )
      setSaving(false)
      return
    }

    setCashCounted('')
    localStorage.removeItem('modas-sophie-cash-counted')
    setMessage('Caja cerrada correctamente.')
    setSaving(false)

    window.dispatchEvent(new Event('modas-sophie-data-updated'))
    await loadCaja()
  }

  const branchName =
    branches.find((branch) => branch.id === branchId)?.name ?? 'Sucursal'

  if (loading) {
    return (
      <main className="inventory-page caja-page">
        <section className="inventory-empty">
          <div>Cargando caja...</div>
        </section>
      </main>
    )
  }

  return (
    <main className="inventory-page caja-page">
      <PageHeader
        title="Caja"
        subtitle="Control de caja del negocio."
        onBack={onBack}
      />

      {userRole === 'admin' && (
        <section className="inventory-section">
          <label htmlFor="caja-branch">
            Sucursal
          </label>

          <select
            id="caja-branch"
            value={branchId}
            onChange={(event) => {
              setBranchId(event.target.value)
              setCashRegister(null)
              setCashCounted('')
            }}
            style={{
              width: '100%',
              boxSizing: 'border-box',
              padding: '14px',
              borderRadius: '14px',
              border: '1px solid #ddd',
              fontSize: '17px',
            }}
          >
            {branches.map((branch) => (
              <option key={branch.id} value={branch.id}>
                {branch.name}
              </option>
            ))}
          </select>

          <div className="cash-branch-current">
            <span>Sucursal actual</span>
            <strong>{branchName}</strong>
          </div>
        </section>
      )}

      {error && (
        <section className="inventory-section cash-message-card">
          <div className="cash-error-message">{error}</div>
        </section>
      )}

      {message && (
        <section className="inventory-section cash-message-card">
          <div className="cash-success-message">{message}</div>
        </section>
      )}

      {!cashRegister ? (
        userRole === 'admin' ? (
          <section className="inventory-section cash-action-card">
            <div className="cash-card-heading">
              <div className="cash-status-icon cash-status-open">●</div>
              <div>
                <h2>Abrir caja</h2>
                <p>Introduce el efectivo con el que comienzas a trabajar.</p>
              </div>
            </div>

            <label htmlFor="opening-cash">
              Efectivo inicial
            </label>

            <input
              id="opening-cash"
              type="number"
              min="0"
              step="0.01"
              inputMode="decimal"
              value={openingCash}
              onChange={(event) => setOpeningCash(event.target.value)}
              placeholder="0.00"

              className="cash-number-input"
            />

            <button
              type="button"
              className="cash-action-button cash-open-button"
              onClick={abrirCaja}
              disabled={saving}
            >
              {saving ? 'Abriendo caja...' : '🟢 Abrir caja'}
            </button>
          </section>
        ) : (
          <section className="inventory-section cash-shared-card">
            <div className="cash-card-heading">
              <div className="cash-status-icon cash-status-shared">●</div>
              <div>
                <h2>Caja compartida</h2>
                <p>
                  La caja de esta sucursal es compartida.
                  El administrador es quien abre y cierra la caja.
                </p>
              </div>
            </div>
          </section>
        )
      ) : (
        <>
          <section className="inventory-section cash-open-card">
            <div className="cash-card-heading">
              <div className="cash-status-icon cash-status-open">●</div>
              <div>
                <h2>Caja abierta</h2>
                <p>Resumen de movimientos de la caja actual.</p>
              </div>
            </div>

            <div className="cash-summary-list">
              <div className="cash-summary-row">
                <span>Efectivo inicial</span>
                <strong>{money(Number(cashRegister.opening_cash))}</strong>
              </div>

              <div className="cash-summary-row">
                <span>Ventas en efectivo</span>
                <strong>{money(efectivoVentas)}</strong>
              </div>

              <div className="cash-summary-row">
                <span>Gastos</span>
                <strong>{money(totalGastos)}</strong>
              </div>
            </div>

            <div
              style={{
                marginTop: '18px',
                padding: '20px',
                borderRadius: '18px',
                background: '#f7f7fb',
                border: '1px solid #ead5e0',
                textAlign: 'center',
              }}
            >
              <div style={{ color: '#777' }}>
                Efectivo esperado en caja
              </div>

              <strong style={{ fontSize: '32px' }}>
                {money(efectivoEsperado)}
              </strong>
            </div>
          </section>

          {userRole === 'admin' && (
          <section className="inventory-section cash-close-card">
            <div className="cash-card-heading">
              <div className="cash-status-icon cash-status-close">●</div>
              <div>
                <h2>Cerrar caja</h2>
                <p>Cuenta físicamente el efectivo e introdúcelo aquí.</p>
              </div>
            </div>

            <label htmlFor="cash-counted">
              Efectivo contado
            </label>

            <input
              id="cash-counted"
              type="number"
              min="0"
              step="0.01"
              inputMode="decimal"
              value={cashCounted}
              onChange={(event) =>
                setCashCounted(event.target.value)
              }
              placeholder="0.00"

              className="cash-number-input"
            />

            {diferencia !== null && (
              <div
                style={{
                  marginTop: '16px',
                  padding: '18px',
                  borderRadius: '16px',
                  background:
                    diferencia === 0
                      ? '#effaf1'
                      : diferencia > 0
                        ? '#eef5ff'
                        : '#fff1f1',
                  border: '1px solid #ddd',
                  textAlign: 'center',
                }}
              >
                <div style={{ color: '#777' }}>
                  Diferencia
                </div>

                <strong style={{ fontSize: '26px' }}>
                  {diferencia === 0
                    ? '✅ Caja cuadrada'
                    : diferencia > 0
                      ? `🟢 Sobrante de ${money(diferencia)}`
                      : `🔴 Faltante de ${money(
                          Math.abs(diferencia)
                        )}`}
                </strong>
              </div>
            )}

            <button
              type="button"
              className="cash-action-button cash-close-button"
              onClick={cerrarCaja}
              disabled={saving}
            >
              {saving ? 'Cerrando caja...' : '🔴 Cerrar caja'}
            </button>
          </section>
          )}
        </>
      )}

      {userRole === 'admin' && (
        <section className="inventory-section cash-admin-note">
          <p>Administrador: puedes abrir y cerrar la caja.</p>
        </section>
      )}
    </main>
  )
}
